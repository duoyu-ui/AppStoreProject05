//
//  ViewController.h
//  iOS2048Tetris
//
//  Created by Earth on 2020/9/29.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
