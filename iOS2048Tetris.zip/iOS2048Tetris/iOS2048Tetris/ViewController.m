//
//  ViewController.m
//  iOS2048Tetris
//
//  Created by Earth on 2020/9/29.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

}

- (BOOL)shouldAutorotate {
    return NO;
}


@end

